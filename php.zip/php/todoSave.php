<?php
	//http://stackoverflow.com/questions/18382740/cors-not-working-php
	if (isset($_SERVER['HTTP_ORIGIN'])) {
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }

    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers:        {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }


    //http://stackoverflow.com/questions/15485354/angular-http-post-to-php-and-undefined
    $postdata = file_get_contents("php://input");
	if (isset($postdata)) {
	
		$request = json_decode($postdata);
        $title = $request->title;
        $idTodo = $request->idTodo;
		$startDate = $request->startDate;
		$dueDate = $request->dueDate;
		$startDate = str_replace("T", " ",$startDate);
		$dueDate = str_replace("T", " ",$dueDate);
		$sDate = explode(".",$startDate);
		$dDate = explode(".",$dueDate);
		$startDate = $sDate[0];
		$dueDate = $dDate[0];

		$mytags = $request->mytags;

		//print_r($mytags); // "My tags ". $mytags;
		
		$notes = $request->notes;
		$ownerId = $request->ownerId;
		$title = strip_tags(trim($title));
		$notes = strip_tags(trim($notes));
		$userId ="561551be3bb43a5bd431c2fc";
		$error = 0;
		$success = 1;
		include 'dbc.php';
		$sql = "update todo set userid ='$userId',title ='$title',notes ='$notes',startDate = '$startDate',dueDate = '$dueDate',ownerId = '$ownerId' where id= '$idTodo'";
		//echo $sql;
        $sqlData = mysql_query($sql);
        
		if($sqlData){
            // delete all tags
            $sqlDelete = "delete from tagsTodo where taskId ='$idTodo'";
            //echo  $sqlDelete;
            $resultdelete = mysql_query($sqlDelete);
			foreach($mytags as $key=>$value){
				$name = $value->name;
				$label =  $value->label;
				$colorCode = $value->color;
				// Check if the tags has been created before
				$sqlTags = mysql_query("Select id from tags where name='$name' limit 1");
				if(mysql_num_rows($sqlTags) >= 1){
					$rowTags = mysql_fetch_array($sqlTags);
					$idTag = $rowTags['id'];
				}
				else{
					$sql = "INSERT INTO tags (name,label,color) VALUES ('$name','$name','$colorCode')";
					//echo $sql;
					$sqlData = mysql_query($sql);
					$sqlGetId = mysql_query("Select id from tags where name='$name' limit 1");
					$rowIdnw = mysql_fetch_array($sqlGetId);
					$idTag = $rowIdnw['id'];
                }
                
				// Insert tags to tagsTodo
				$sqlTod = "insert into tagsTodo (tagsId,taskId) values ('$idTag','$idTodo')";
				///echo $sqlTod;
				$sqlTagsTodo = mysql_query($sqlTod);
			}
			echo $success;
		}
		else{
			echo $error;
		}
		
		
	}
	
		
?>