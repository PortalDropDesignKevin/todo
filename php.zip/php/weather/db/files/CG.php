<?php
/* File with stationnames in Congo */

$country = 'Congo';

$icaos   = array(
  'FCBB' => 'Brazzaville / Maya-Maya',
  'FCBD' => 'Djambala',
  'FCOG' => 'Gamboma',
  'FCOI' => 'Impfondo',
  'FZAA' => 'Kinshasa / N\'Djili',
  'FCPL' => 'Loubomo',
  'FCBO' => 'M\'Pouya',
  'FCPA' => 'Makabana',
  'FCOM' => 'Makoua',
  'FCBM' => 'Mouyondzi',
  'FCOU' => 'Ouesso',
  'FCPP' => 'Pointe-Noire',
  'FCBS' => 'Sibiti',
  'FCOS' => 'Souanke'
);

?>
