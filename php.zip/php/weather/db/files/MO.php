<?php
/* File with stationnames in Macau */

$country = 'Macau';

$icaos   = array(
  'VMMC' => 'Taipa'
);

?>
