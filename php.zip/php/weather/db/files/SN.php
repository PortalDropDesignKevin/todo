<?php
/* File with stationnames in Senegal */

$country = 'Senegal';

$icaos   = array(
  'GOGS' => 'Cap-Skirring',
  'GOOY' => 'Dakar / Yoff',
  'GOOD' => 'Diourbel',
  'GOOK' => 'Kaolack',
  'GOTK' => 'Kedougou',
  'GOGK' => 'Kolda',
  'GOOG' => 'Linguere',
  'GOSM' => 'Matam',
  'GOSP' => 'Podor',
  'GOSS' => 'Saint-Louis',
  'GOTT' => 'Tambacounda',
  'GOGG' => 'Ziguinchor'
);

?>
