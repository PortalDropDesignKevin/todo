<?php
/* File with stationnames in Moldova, Republic of */

$country = 'Moldova, Republic of';

$icaos   = array(
  'UKII' => 'Kisinev'
);

?>
