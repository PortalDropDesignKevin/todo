<?php
/* File with stationnames in Oman */

$country = 'Oman';

$icaos   = array(
  'OOBR' => 'Buraimi',
  'OOFD' => 'Fahud',
  'OOKB' => 'Khassab',
  'OOMA' => 'Masirah',
  'OOSQ' => 'Saiq',
  'OOSA' => 'Salalah',
  'OOMS' => 'Seeb, International Airport',
  'OOSH' => 'Sohar Majis',
  'OOSR' => 'Sur',
  'OOTH' => 'Thumrait'
);

?>
