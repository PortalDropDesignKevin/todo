<?php
/* File with stationnames in Saint Helena */

$country = 'Saint Helena';

$icaos   = array(
  'FHAW' => 'Wide Awake Field Ascension Island'
);

?>
