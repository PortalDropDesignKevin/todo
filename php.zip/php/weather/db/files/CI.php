<?php
/* File with stationnames in Cote D'Ivoire */

$country = 'Cote D\'Ivoire';

$icaos   = array(
  'DIAP' => 'Abidjan',
  'DIAD' => 'Adiake',
  'DIBU' => 'Bondoukou',
  'DIBK' => 'Bouake',
  'DIDL' => 'Daloa',
  'DIDK' => 'Dimbokro',
  'DIGA' => 'Gagnoa',
  'DIKO' => 'Korhogo',
  'DIMN' => 'Man',
  'DIOD' => 'Odienne',
  'DISP' => 'San Pedro',
  'DISS' => 'Sassandra',
  'DITB' => 'Tabou',
  'DIYO' => 'Yamoussoukro'
);

?>
