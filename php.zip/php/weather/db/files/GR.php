<?php
/* File with stationnames in Greece */

$country = 'Greece';

$icaos   = array(
  'LGPZ' => 'Aktion Airport',
  'LGAL' => 'Alexandroupoli Airport',
  'LGBL' => 'Anchialos Airport',
  'LGAD' => 'Andravida Airport',
  'LGRX' => 'Araxos Airport',
  'LGAT' => 'Athinai Airport',
  'LGHI' => 'Chios Airport',
  'LGKV' => 'Chrysoupoli Airport',
  'LGEL' => 'Elefsis Airport',
  'LGIR' => 'Heraklion Airport',
  'LGKL' => 'Kalamata Airport',
  'LGKP' => 'Karpathos Airport',
  'LGKA' => 'Kastoria Airport',
  'LGKF' => 'Kefalhnia Airport',
  'LGKR' => 'Kerkyra Airport',
  'LGKO' => 'Kos Airport',
  'LGKZ' => 'Kozani Airport',
  'LGLR' => 'Larissa Airport',
  'LGLM' => 'Limnos Airport',
  'LGMT' => 'Mytilini Airport',
  'LGRP' => 'Rhodes Airport',
  'LGSM' => 'Samos Airport',
  'LGSR' => 'Santorini Island',
  'LGSK' => 'Skiathos Island',
  'LGSA' => 'Souda Airport',
  'LGTG' => 'Tanagra Airport',
  'LGTT' => 'Tatoi',
  'LGTS' => 'Thessaloniki Airport',
  'LGTP' => 'Tripolis Airport',
  'LGZA' => 'Zakinthos Airport'
);

?>
