<?php
/* File with stationnames in Macedonia, the Former Yugoslav Republic of */

$country = 'Macedonia, the Former Yugoslav Republic of';

$icaos   = array(
  'LWOH' => 'Ohrid',
  'LWSK' => 'Skopje-Petrovec'
);

?>
