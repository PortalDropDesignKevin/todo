<?php
/* File with stationnames in Gabon */

$country = 'Gabon';

$icaos   = array(
  'FOOB' => 'Bitam',
  'FOOC' => 'Cocobeach',
  'FOON' => 'Franceville / Mvengue',
  'FOGR' => 'Lambarene',
  'FOOR' => 'Lastoursville',
  'FOOL' => 'Libreville',
  'FOOK' => 'Makokou',
  'FOOY' => 'Mayumba',
  'FOOE' => 'Mekambo',
  'FOOM' => 'Mitzic',
  'FOOD' => 'Moanda',
  'FOGM' => 'Mouila',
  'FOOG' => 'Port-Gentil',
  'FOOT' => 'Tchibanga'
);

?>
