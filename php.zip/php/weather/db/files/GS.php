<?php
/* File with stationnames in South Georgia and the South Sandwich Islands */

$country = 'South Georgia and the South Sandwich Islands';

$icaos   = array(
  'EGYP' => 'Mount Pleasant Airport'
);

?>
