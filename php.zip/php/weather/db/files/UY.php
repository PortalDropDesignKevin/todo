<?php
/* File with stationnames in Uruguay */

$country = 'Uruguay';

$icaos   = array(
  'SUAG' => 'Artigas',
  'SULS' => 'Capitan Corbeta',
  'SUMU' => 'Carrasco',
  'SUCA' => 'Colonia',
  'SUDU' => 'Durazno',
  'SUPE' => 'Maldonado / Punta Est',
  'SUAA' => 'Melilla',
  'SUMO' => 'Melo',
  'SUME' => 'Mercedes',
  'SUPU' => 'Paysandu',
  'SURV' => 'Rivera',
  'SUSO' => 'Salto',
  'SUTB' => 'Tacuarembo',
  'SUTR' => 'Treinta Y Tres'
);

?>
