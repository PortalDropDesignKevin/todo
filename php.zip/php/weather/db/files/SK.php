<?php
/* File with stationnames in Slovakia */

$country = 'Slovakia';

$icaos   = array(
  'LZIB' => 'Bratislava Ivanka',
  'LZKC' => 'Kamenica Nad Cirochou',
  'LKKZ' => 'Kosice',
  'LZLU' => 'Lucenec',
  'LKPP' => 'Piestany',
  'LZTT' => 'Poprad / Tatry',
  'LKSL' => 'Sliac'
);

?>
