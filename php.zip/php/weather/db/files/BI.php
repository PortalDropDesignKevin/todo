<?php
/* File with stationnames in Burundi */

$country = 'Burundi';

$icaos   = array(
  'HBBA' => 'Bujumbura'
);

?>
