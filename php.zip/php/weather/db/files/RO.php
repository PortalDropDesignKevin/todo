<?php
/* File with stationnames in Romania */

$country = 'Romania';

$icaos   = array(
  'LRAR' => 'Arad',
  'LRBC' => 'Bacau',
  'LRBM' => 'Baia Mare',
  'LRBS' => 'Bucuresti / Imh',
  'LROP' => 'Bucuresti Otopeni',
  'LRCS' => 'Caransebes',
  'LRCL' => 'Cluj-Napoca',
  'LRCV' => 'Craiova',
  'LRIA' => 'Iasi',
  'LRCK' => 'Kogalniceanu',
  'LROD' => 'Oradea',
  'LRSM' => 'Satu Mare',
  'LRSB' => 'Sibiu',
  'LRSV' => 'Suceava / Salcea',
  'LRTR' => 'Timisoara',
  'LRTM' => 'Tirgu Mures',
  'LRTC' => 'Tulcea'
);

?>
