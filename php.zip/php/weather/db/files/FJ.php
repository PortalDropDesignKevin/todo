<?php
/* File with stationnames in Fiji */

$country = 'Fiji';

$icaos   = array(
  'NFNK' => 'Lakemba',
  'NFFN' => 'Nandi',
  'NFNA' => 'Nausori',
  'NFNR' => 'Rotuma'
);

?>
