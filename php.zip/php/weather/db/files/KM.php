<?php
/* File with stationnames in Comoros */

$country = 'Comoros';

$icaos   = array(
  'FMCZ' => 'Dzaoudzi / Pamanzi Mayotte',
  'FMCH' => 'Hahaya International Airport',
  'FMCV' => 'Ouani Anjouan'
);

?>
