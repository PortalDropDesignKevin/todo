<?php
/* File with stationnames in Zambia */

$country = 'Zambia';

$icaos   = array(
  'FLCP' => 'Chipata',
  'FLCH' => 'Choma',
  'FLIK' => 'Isoka',
  'FLPO' => 'Kabompo',
  'FLKW' => 'Kabwe',
  'FLKO' => 'Kaoma',
  'FLKS' => 'Kasama',
  'FLPA' => 'Kasempa',
  'FLKB' => 'Kawambwa',
  'FLLI' => 'Livingstone',
  'FLLD' => 'Lundazi',
  'FLLC' => 'Lusaka City Airport',
  'FLLS' => 'Lusaka Internationalairport',
  'FLMA' => 'Mansa',
  'FLBA' => 'Mbala',
  'FLMG' => 'Mongu',
  'FLMP' => 'Mpika',
  'FLMW' => 'Mwinilunga',
  'FLND' => 'Ndola',
  'FLPE' => 'Petauke',
  'FLSN' => 'Senanga',
  'FLSE' => 'Serenje',
  'FLSS' => 'Sesheke',
  'FLSW' => 'Solwezi',
  'FLZB' => 'Zambezi'
);

?>
