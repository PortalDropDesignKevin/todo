<?php
/* File with stationnames in Georgia */

$country = 'Georgia';

$icaos   = array(
  'UGMM' => 'Muhrani',
  'UGGG' => 'Tbilisi'
);

?>
