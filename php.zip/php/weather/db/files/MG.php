<?php
/* File with stationnames in Madagascar */

$country = 'Madagascar';

$icaos   = array(
  'FMNL' => 'Analalava',
  'FMND' => 'Andapa',
  'FMNH' => 'Antalaha',
  'FMMI' => 'Antananarivo / Ivato',
  'FMME' => 'Antsirabe',
  'FMNQ' => 'Besalampy',
  'FMNA' => 'Diego-Suarez',
  'FMSG' => 'Farafangana',
  'FMNN' => 'Fascene Nossi-Be',
  'FMSF' => 'Fianarantsoa',
  'FMSD' => 'Fort-Dauphin',
  'FMMH' => 'Mahanoro',
  'FMMO' => 'Maintirano',
  'FMNM' => 'Majunga',
  'FMSM' => 'Mananjary',
  'FMSR' => 'Morombe',
  'FMMV' => 'Morondava',
  'FMSO' => 'Ranohira',
  'FMMS' => 'Sainte-Marie Aerodrome',
  'FMNS' => 'Sambava',
  'FMMT' => 'Tamatave',
  'FMST' => 'Tulear',
  'FMNV' => 'Vohemar'
);

?>
