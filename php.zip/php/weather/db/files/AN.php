<?php
/* File with stationnames in Netherlands Antilles */

$country = 'Netherlands Antilles';

$icaos   = array(
  'TNCB' => 'Flamingo Airport, Bonaire',
  'TNCC' => 'Hato Airport, Curacao',
  'TNCM' => 'Juliana Airport, Saint Maarten',
  'TNCE' => 'Roosevelt Airport Saint Eustatius'
);

?>
