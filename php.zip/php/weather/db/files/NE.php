<?php
/* File with stationnames in Niger */

$country = 'Niger';

$icaos   = array(
  'DRZA' => 'Agadez',
  'DRRI' => 'Bilma',
  'DRRB' => 'Birni-N\'Konni',
  'DRZF' => 'Diffa',
  'DRRG' => 'Gaya',
  'DRZG' => 'Goure',
  'DRZM' => 'Maine-Soroa',
  'DRRM' => 'Maradi',
  'DRRN' => 'Niamey-Aero',
  'DRRT' => 'Tahoua',
  'DRRL' => 'Tillabery',
  'DRZR' => 'Zinder'
);

?>
