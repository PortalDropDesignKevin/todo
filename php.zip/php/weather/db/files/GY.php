<?php
/* File with stationnames in Guyana */

$country = 'Guyana';

$icaos   = array(
  'SYGT' => 'Georgetown',
  'SYTM' => 'Timehri Airport'
);

?>
