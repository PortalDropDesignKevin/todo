<?php
/* File with stationnames in Nigeria */

$country = 'Nigeria';

$icaos   = array(
  'DNBI' => 'Bida',
  'DNCA' => 'Calabar',
  'DNEN' => 'Enugu',
  'DNGU' => 'Gusau',
  'DNIB' => 'Ibadan',
  'DNIL' => 'Ilorin',
  'DNJO' => 'Jos',
  'DNKA' => 'Kaduna',
  'DNKN' => 'Kano',
  'DNMM' => 'Lagos / Ikeja',
  'DNMA' => 'Maiduguri',
  'DNMK' => 'Makurdi',
  'DNOS' => 'Oshogbo',
  'DNPO' => 'Port Harcourt',
  'DNSO' => 'Sokoto',
  'DNYO' => 'Yola',
  'DNZA' => 'Zaria'
);

?>
