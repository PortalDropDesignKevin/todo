<?php
/* File with stationnames in Seychelles */

$country = 'Seychelles';

$icaos   = array(
  'FSIA' => 'Seychelles Inter-National Airport',
  'FSSS' => 'Seychelles International Airport'
);

?>
