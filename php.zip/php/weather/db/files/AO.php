<?php
/* File with stationnames in Angola */

$country = 'Angola';

$icaos   = array(
  'FNKU' => 'Bie Silva Porto',
  'FNCA' => 'Cabinda',
  'FNHU' => 'Huambo Nova Lisboa',
  'FNLU' => 'Luanda',
  'FNBG' => 'Monbaca Benguela'
);

?>
