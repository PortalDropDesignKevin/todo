<?php
/* File with stationnames in Chad */

$country = 'Chad';

$icaos   = array(
  'FTTC' => 'Abeche',
  'FTTN' => 'Am-Timan',
  'FTTK' => 'Bokoro',
  'FTTL' => 'Bol-Berim',
  'FTTY' => 'Faya',
  'FTTD' => 'Moundou',
  'FTTJ' => 'Ndjamena',
  'FTTP' => 'Pala',
  'FTTA' => 'Sarh'
);

?>
