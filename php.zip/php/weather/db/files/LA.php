<?php
/* File with stationnames in Lao People's Democratic Republic */

$country = 'Lao People\'s Democratic Republic';

$icaos   = array(
  'VLAP' => 'Attopeu',
  'VLLB' => 'Luang-Prabang',
  'VLIP' => 'Pakse',
  'VLSV' => 'Saravane',
  'VLSK' => 'Savannakhet',
  'VLSB' => 'Sayaboury',
  'VLTK' => 'Thakhek',
  'VLVT' => 'Vientiane'
);

?>
