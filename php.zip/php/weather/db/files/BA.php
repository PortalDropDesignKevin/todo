<?php
/* File with stationnames in Bosnia and Herzegovina */

$country = 'Bosnia and Herzegovina';

$icaos   = array(
  'LQLV' => 'Livno'
);

?>
