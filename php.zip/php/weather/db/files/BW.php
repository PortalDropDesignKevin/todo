<?php
/* File with stationnames in Botswana */

$country = 'Botswana';

$icaos   = array(
  'FBFT' => 'Francistown',
  'FBGZ' => 'Ghanzi',
  'FBJW' => 'Jwaneng',
  'FBKE' => 'Kasane',
  'FBLT' => 'Letlhakane',
  'FBMN' => 'Maun',
  'FBSK' => 'Seretse Khama International Airport',
  'FBSW' => 'Shakawe',
  'FBSN' => 'Sua-Pan',
  'FBTS' => 'Tsabong',
  'FBTE' => 'Tshane'
);

?>
