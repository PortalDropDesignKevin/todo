<?php
/* File with stationnames in Greenland */

$country = 'Greenland';

$icaos   = array(
  'BGAS' => 'Angisoq',
  'BGAT' => 'Aputiteeq',
  'BGKT' => 'Cape Tobin Automated Reporting S',
  'BGCO' => 'Constable Pynt',
  'BGDB' => 'Daneborg',
  'BGDH' => 'Danmarkshavn',
  'BGEM' => 'Egedesminde',
  'BGFH' => 'Frederikshaab',
  'BGGH' => 'Godthaab / Nuuk',
  'BGGD' => 'Groennedal',
  'BGHB' => 'Holsteinsborg',
  'BGJN' => 'Jacobshavn Lufthavn',
  'BGJH' => 'Julianehaab',
  'BGKK' => 'Kulusuk Lufthavn',
  'BGBW' => 'Narsarsuaq',
  'BGPC' => 'Prins Christian Sund',
  'BGSC' => 'Scoresbysund',
  'BGSF' => 'Sdr Stroemfjord',
  'BGAM' => 'Tasiilaq',
  'BGTL' => 'Thule A. B.'
);

?>
