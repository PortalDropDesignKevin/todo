<?php
/* File with stationnames in Rwanda */

$country = 'Rwanda';

$icaos   = array(
  'HRYG' => 'Gisenyi',
  'HRYR' => 'Kigali'
);

?>
