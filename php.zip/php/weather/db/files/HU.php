<?php
/* File with stationnames in Hungary */

$country = 'Hungary';

$icaos   = array(
  'LHBC' => 'B�k�scsaba',
  'LHBS' => 'Buda�rs',
  'LHBP' => 'Budapest / Ferihegy',
  'LHBM' => 'Budapest Met Center',
  'LHDC' => 'Debrecen',
  'LHKV' => 'Kaposv�r',
  'LHKE' => 'Kecskem�t',
  'LHMC' => 'Miskolc',
  'LHNY' => 'Nyiregyh�za / Napkor',
  'LHPA' => 'P�pa',
  'LHPP' => 'P�cs / Pog�ny',
  'LHSK' => 'Si�fok',
  'LHUD' => 'Szeged',
  'LHSN' => 'Szolnok',
  'LHSY' => 'Szombathely'
);

?>
