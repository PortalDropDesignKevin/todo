<?php
/* File with stationnames in Gambia */

$country = 'Gambia';

$icaos   = array(
  'GBYD' => 'Banjul / Yundum'
);

?>
