<?php
/* File with stationnames in Cambodia */

$country = 'Cambodia';

$icaos   = array(
  'VDKC' => 'Kompong-Cham',
  'VDPP' => 'Phnom-Penh / Pochentong',
  'VDSR' => 'Siemreap'
);

?>
