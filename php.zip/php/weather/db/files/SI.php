<?php
/* File with stationnames in Slovenia */

$country = 'Slovenia';

$icaos   = array(
  'LJLJ' => 'Ljubljana / Brnik',
  'LYLJ' => 'Ljubljana / Brnik',
  'LJMB' => 'Maribor / Slivnica',
  'LJMS' => 'Murska Sobota',
  'LJPZ' => 'Portoroz',
  'LYPZ' => 'Portoroz / Secovlje'
);

?>
