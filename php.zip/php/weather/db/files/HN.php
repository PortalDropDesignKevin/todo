<?php
/* File with stationnames in Honduras */

$country = 'Honduras';

$icaos   = array(
  'MHAM' => 'Amapala',
  'MHCA' => 'Catacamas',
  'MHCH' => 'Choluteca',
  'MHNO' => 'Guanaja',
  'MHIC' => 'Islas Del Cisne',
  'MHLC' => 'La Ceiba Airport',
  'MHLE' => 'La Esperanza',
  'MHLM' => 'La Mesa San Pedro Sula',
  'MHSC' => 'Nueva Ocotepeque',
  'MHPL' => 'Puerto Lempira',
  'MHRO' => 'Roatan',
  'MHSR' => 'Santa Rosa De Copan',
  'MHTG' => 'Tegucigalpa',
  'MHTE' => 'Tela',
  'MHYR' => 'Yoro'
);

?>
