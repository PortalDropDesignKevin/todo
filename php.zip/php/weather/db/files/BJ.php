<?php
/* File with stationnames in Benin */

$country = 'Benin';

$icaos   = array(
  'DBBC' => 'Bohicon',
  'DBBB' => 'Cotonou',
  'DBBK' => 'Kandi',
  'DBBN' => 'Natitingou',
  'DBBP' => 'Parakou',
  'DBBS' => 'Save'
);

?>
