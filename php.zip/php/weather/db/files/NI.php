<?php
/* File with stationnames in Nicaragua */

$country = 'Nicaragua';

$icaos   = array(
  'MNBL' => 'Bluefields',
  'MNCH' => 'Chinandega',
  'MNJG' => 'Jinotega',
  'MNJU' => 'Juigalpa',
  'MNMG' => 'Managua A. C. Sandino',
  'MNPC' => 'Puerto Cabezas',
  'MNRS' => 'Rivas'
);

?>
