<?php
/* File with stationnames in Czech Republic */

$country = 'Czech Republic';

$icaos   = array(
  'LKTB' => 'Brno / Turany',
  'LKHO' => 'Holesov',
  'LKKV' => 'Karlovy Vary',
  'LKMT' => 'Ostrava / Mosnov',
  'LKPR' => 'Praha / Ruzyne'
);

?>
