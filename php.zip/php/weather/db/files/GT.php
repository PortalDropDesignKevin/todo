<?php
/* File with stationnames in Guatemala */

$country = 'Guatemala';

$icaos   = array(
  'MGCB' => 'Coban',
  'MGFL' => 'Flores',
  'MGGT' => 'Guatemala Aeropuertola Aurora',
  'MGHT' => 'Huehuetenango',
  'MGPB' => 'Puerto Barrios',
  'MGQZ' => 'Quezaltenango',
  'MGRT' => 'Retalhuleu',
  'MGSJ' => 'San Jose',
  'MGZA' => 'Zacapa'
);

?>
