<?php
/* File with stationnames in Cayman Islands */

$country = 'Cayman Islands';

$icaos   = array(
  'MWCR' => 'Owen Roberts Airportgrand Cayman'
);

?>
