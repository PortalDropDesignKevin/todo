<?php
/* File with stationnames in Palau */

$country = 'Palau';

$icaos   = array(
  'PTRO' => 'Koror / Palau Island'
);

?>
