<?php
/* File with stationnames in Ireland */

$country = 'Ireland';

$icaos   = array(
  'EIME' => 'Casement Aerodrome',
  'EICK' => 'Cork Airport',
  'EIDW' => 'Dublin Airport',
  'EINN' => 'Shannon Airport'
);

?>
