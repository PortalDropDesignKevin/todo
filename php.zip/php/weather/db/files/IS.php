<?php
/* File with stationnames in Iceland */

$country = 'Iceland';

$icaos   = array(
  'BIAR' => 'Akureyri',
  'BIHN' => 'Akurnes',
  'BIEG' => 'Egilsstadir',
  'BIGR' => 'Grimsey',
  'BIKF' => 'Keflavikurflugvollur',
  'BIRG' => 'Raufarhofn',
  'BIRK' => 'Reykjavik',
  'BIVO' => 'Skjaldthingsstadir',
  'BIST' => 'Stykkisholmur',
  'BIVM' => 'Vestmannaeyjar'
);

?>
