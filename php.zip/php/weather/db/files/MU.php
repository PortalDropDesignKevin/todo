<?php
/* File with stationnames in Mauritius */

$country = 'Mauritius';

$icaos   = array(
  'FIMP' => 'Plaisance Mauritius',
  'FIMR' => 'Rodrigues'
);

?>
