<?php
/* File with stationnames in Syrian Arab Republic */

$country = 'Syrian Arab Republic';

$icaos   = array(
  'OSAP' => 'Aleppo International Airport',
  'OSDI' => 'Damascus Int. Airport',
  'OSDZ' => 'Deir Ezzor',
  'OSKL' => 'Kamishli',
  'OSLK' => 'Lattakia',
  'OSPR' => 'Palmyra'
);

?>
