<?php
/* File with stationnames in Austria */

$country = 'Austria';

$icaos   = array(
  'LOXA' => 'Aigen Im Ennstal',
  'LOWG' => 'Graz-Thalerhof-Flughafen',
  'LOXL' => 'Horsching Aus-Afb',
  'LOWI' => 'Innsbruck-Flughafen',
  'LOWK' => 'Klagenfurt-Flughafen',
  'LOWL' => 'Linz / Hoersching-Flughafen',
  'LOAV' => 'Niederosterreich / Lugplatz  Vos',
  'LOWS' => 'Salzburg-Flughafen',
  'LOXS' => 'Schwaz Heliport',
  'LOXT' => 'Tulln',
  'LOWW' => 'Wien / Schwechat-Flughafen',
  'LOXZ' => 'Zeltweg'
);

?>
