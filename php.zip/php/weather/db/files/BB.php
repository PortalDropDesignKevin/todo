<?php
/* File with stationnames in Barbados */

$country = 'Barbados';

$icaos   = array(
  'TBPB' => 'Grantley Adams'
);

?>
