<?php
/* File with stationnames in Dominica */

$country = 'Dominica';

$icaos   = array(
  'TDCF' => 'Canefield Airport',
  'TDPD' => 'Melville Hall Airport',
  'TDPR' => 'Roseau'
);

?>
