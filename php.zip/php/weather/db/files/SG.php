<?php
/* File with stationnames in Singapore */

$country = 'Singapore';

$icaos   = array(
  'WSSS' => 'Singapore / Changi Airport',
  'WSAP' => 'Singapore / Paya Lebar'
);

?>
