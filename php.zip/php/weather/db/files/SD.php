<?php
/* File with stationnames in Sudan */

$country = 'Sudan';

$icaos   = array(
  'HSAT' => 'Atbara',
  'HSDZ' => 'Damazine',
  'HSDN' => 'Dongola',
  'HSFS' => 'El Fasher',
  'HSOB' => 'El Obeid',
  'HSGF' => 'Gedaref',
  'HSGN' => 'Geneina',
  'HSSJ' => 'Juba',
  'HSLI' => 'Kadugli',
  'HSKA' => 'Kassala',
  'HSSS' => 'Khartoum',
  'HSKI' => 'Kosti',
  'HSSM' => 'Malakal',
  'HSNL' => 'Nyala',
  'HSSP' => 'Port Sudan',
  'HSRN' => 'Renk',
  'HSNR' => 'Sennar',
  'HSSW' => 'Wadi Halfa'
);

?>
