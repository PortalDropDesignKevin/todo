<?php
/* File with stationnames in Tunisia */

$country = 'Tunisia';

$icaos   = array(
  'DTTB' => 'Bizerte',
  'DTTJ' => 'Djerba Mellita',
  'DTTR' => 'El Borma',
  'DTTG' => 'Gabes',
  'DTTF' => 'Gafsa',
  'DTMB' => 'Habib Bourguiba',
  'DTTN' => 'Jendouba',
  'DTTK' => 'Kairouan',
  'DTTL' => 'Kelibia',
  'DTTM' => 'Monastir-Skanes',
  'DTTD' => 'Remada',
  'DTTX' => 'Sfax El-Maou',
  'DTKA' => 'Tabarka',
  'DTTZ' => 'Tozeur',
  'DTTA' => 'Tunis-Carthage'
);

?>
