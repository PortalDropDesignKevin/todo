<?php
/* File with stationnames in Kazakhstan */

$country = 'Kazakhstan';

$icaos   = array(
  'UATT' => 'Aktjubinsk',
  'UAAA' => 'Almaty',
  'UARR' => 'Uralsk'
);

?>
