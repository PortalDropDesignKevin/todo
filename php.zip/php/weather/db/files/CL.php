<?php
/* File with stationnames in Chile */

$country = 'Chile';

$icaos   = array(
  'SCFA' => 'Antofagasta',
  'SCAR' => 'Arica',
  'SCBA' => 'Balmaceda',
  'SCRA' => 'Chanaral',
  'SCCC' => 'Chile Chico',
  'SCCH' => 'Chillan',
  'SCHR' => 'Cochrane',
  'SCIE' => 'Concepcion',
  'SCHA' => 'Copiapo',
  'SCCY' => 'Coyhaique',
  'SCIC' => 'Curico',
  'SCDA' => 'Iquique / Diego Arac',
  'SCIP' => 'Isla De Pascua',
  'SCSE' => 'La Serena',
  'SCEL' => 'Pudahuel',
  'SCTE' => 'Puerto Montt',
  'SCCI' => 'Punta Arenas',
  'SCER' => 'Quintero Santiago',
  'SCTC' => 'Temuco',
  'SCVD' => 'Valdivia',
  'SCLL' => 'Vallenar'
);

?>
