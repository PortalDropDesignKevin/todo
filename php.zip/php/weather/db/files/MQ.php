<?php
/* File with stationnames in Martinique */

$country = 'Martinique';

$icaos   = array(
  'TFFF' => 'Le Lamentin'
);

?>
