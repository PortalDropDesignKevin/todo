<?php
/* File with stationnames in Congo, The Democratic Republic of */

$country = 'Congo, The Democratic Republic of';

$icaos   = array(
  'FZBO' => 'Bandundu',
  'FZGN' => 'Boende',
  'FZMB' => 'Butembo',
  'FZFK' => 'Gemena',
  'FZNA' => 'Goma',
  'FZVS' => 'Ilebo',
  'FZAN' => 'Inga',
  'FZBA' => 'Inongo',
  'FZRF' => 'Kalemie',
  'FZSA' => 'Kamina / Base',
  'FZUA' => 'Kananga',
  'FZCS' => 'Kenge',
  'FZCA' => 'Kikwit',
  'FZOA' => 'Kindu',
  'FZIA' => 'Kisangani',
  'FZQM' => 'Kolwezi',
  'FZRQ' => 'Kongolo',
  'FZVA' => 'Lodja',
  'FZQA' => 'Lubumbashi-Luano',
  'FZVI' => 'Lusambo',
  'FZRA' => 'Manono',
  'FZAM' => 'Matadi',
  'FZEA' => 'Mbandaka',
  'FZWA' => 'Mbuji-Mayi',
  'FZAG' => 'Moanda',
  'FZNC' => 'Rutshuru',
  'FZUK' => 'Tshikapa'
);

?>
