<?php
/* File with stationnames in Saint Pierre and Miquelon */

$country = 'Saint Pierre and Miquelon';

$icaos   = array(
  'LFVP' => 'Saint-Pierre'
);

?>
