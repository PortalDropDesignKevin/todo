 <?php
 if (isset($_SERVER['HTTP_ORIGIN'])) {
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }

    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers:        {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }
include("dbc.php");

$user_id = $_GET['user_id'];

$result = mysql_query("SELECT * FROM acc_transaction where trans_senderId = 1 and trans_status='pending' ORDER BY trans_id DESC limit 1");
/* Fetch all of the remaining rows in the result set */
$response = array();
while($row = mysql_fetch_array($result)){
        // temporary array to create single category
        $tmp = array();
        $tmp["trans_id"] = $row["trans_id"];
        $tmp["trans_type"] = $row["trans_type"];
        $tmp["trans_senderId"] = $row["trans_senderId"];
        $tmp["trans_desitnation"] = $row["trans_desitnation"];
        $tmp["trans_status"] = $row["trans_status"];
        $tmp["trans_timestamp"] = $row["trans_timestamp"];
        $tmp["trans_amount"] = $row["trans_amount"];
        
        // push category to final json array
        array_push($response, $tmp);
    }

echo json_encode($response);

?> 