 <?php
 if (isset($_SERVER['HTTP_ORIGIN'])) {
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }

    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers:        {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }
include("dbc.php");


$sqltags = mysql_query("select * from tags");
/* Fetch all of the remaining rows in the result set */
$response["data"] = array();

while($row = mysql_fetch_array($sqltags)){
	$tmpTags = array();
	$tmpTags["id"] = $row["id"];
	$tmpTags["name"] = $row["name"];
	$tmpTags["label"] = $row["label"];
	$tmpTags["color"] = $row["color"];
	array_push($response["data"], $tmpTags);
}
      

echo json_encode($response);

?> 