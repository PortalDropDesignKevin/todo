 <?php
 if (isset($_SERVER['HTTP_ORIGIN'])) {
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }

    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers:        {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }
include("dbc.php");


$result = mysql_query("select * from todo order by id desc");
/* Fetch all of the remaining rows in the result set */
$response["data"] = array();
while($row = mysql_fetch_array($result)){
	$tagsId = $row["tagsid"];
	$taskId = $row['id'];
        // temporary array to create single category
		$tmp = array();
		$tmp["idtodo"] = $row["id"];
        $tmp["id"] = $row["userid"];
        $tmp["title"] = $row["title"];
        $tmp["notes"] = $row["notes"];
        $tmp["startDate"] = $row["startDate"];
        $tmp["dueDate"] = $row["dueDate"];
		if($row["completed"] == 1){
			$tmp["completed"] = true;
		}
		else{
			$tmp["completed"] = false;
		}
		if($row["starred"] == 1){
			$tmp["starred"] = true;
		}
		else{
			$tmp["starred"] = false;
		}
		if($row["important"] == 1){
			$tmp["important"] = true;
		}
		else{
			$tmp["important"] = false;
		}
		if($row["deleted"] == 1){
			$tmp["deleted"] = true;
		}
		else{
			$tmp["deleted"] = false;
		}
        
		$tmp["tags"] = array();
		$sqltags = mysql_query("select t.id,t.name,t.label,t.color from tags t inner join tagsTodo a on t.id = a.tagsId where a.taskId='$taskId'");
        while($rowTags = mysql_fetch_array($sqltags)){
			$tmpTags = array();
			$tmpTags["id"] = $rowTags["id"];
			$tmpTags["name"] = $rowTags["name"];
			$tmpTags["label"] = $rowTags["label"];
			$tmpTags["color"] = $rowTags["color"];
			array_push($tmp["tags"], $tmpTags);
		}
        // push category to final json array
        array_push($response["data"], $tmp);
    }

echo json_encode($response);

?> 